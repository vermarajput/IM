import React, {Component} from 'react';
import './App.css';
import { Card, Button, CardTitle, CardText, Row, Col, CardImg } from 'reactstrap';
class App extends Component {

    state = {};

    componentDidMount() {
        this.refreshScore();
    }
    
    refreshScore = () => {
        fetch('/api/v1/getScore')
            .then(response => response.text())
            .then(message => {
                this.setState({message: message});
            });
    };

    handleIncrementPlayerOne = () => {
        
        fetch('/api/v1/pointsWonBy?player=Aman', {method: 'post'})
            .then(response => response.text())
            .then(playeroneresp => {
                console.log(playeroneresp);
                this.refreshScore()
            });
    };
    
    handleIncrementPlayerTwo = () => {
        fetch('/api/v1/pointsWonBy?player=Anu', {method: 'post'})
            .then(response => response.text())
            .then(playertworesp => {
                console.log(playertworesp);                
                this.refreshScore()
            });
    };

    render() {
        return (
            <div className="restrict">

                <Row >
                <Col sm="6">
                    <Card body inverse color="primary">
                    <CardTitle className="App-header">Player One</CardTitle>
                    <CardText><h1 className="App-title">Aman</h1></CardText>
                    <CardImg top width="100%" src="/AmanTennis.png" alt="Aman is the Player" />
                    <Button color="warning" size="lg" onClick={this.handleIncrementPlayerOne}>Increment Score</Button>
                    </Card>
                </Col>
                <Col sm="6">
                    <Card body inverse color="warning">
                    <CardTitle className="App-header">Player Two</CardTitle>
                    <CardText><h1 className="App-title">Anu</h1></CardText>
                    <CardImg top width="100%" src="/AnuTennis.png" alt="Anu Rocks" />
                    <Button color="primary" size="lg" onClick={this.handleIncrementPlayerTwo}>Increment Score</Button>
                    </Card>
                </Col>
                </Row>
    
                <div className="restrict">
                <Row>
                    <Col sm="12">
                        <Card body style={{ backgroundColor: '#666', borderColor: '#333' }}>
                        <CardTitle><h1 className="App">Set Score, Game Score</h1></CardTitle>
                        </Card>
                    </Col>
                </Row >              
               
                <Row>
                    <Col sm="12">
                        <Card body>
                        <CardText><h3>Aman-Anu, Aman-Anu</h3></CardText>
                        <CardText><h1 className="App">{this.state.message}</h1></CardText>                        
                        </Card>
                    </Col>
                </Row >              
                </div>
            </div>
        );
    }
}

export default App;
