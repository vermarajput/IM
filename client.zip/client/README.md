# Tennis Score Orchestrator
Tennis Score Orchestrator is the solution to increment the score for two players and declare winner per set and for a match based on decision criteria

### Screenshots
![](/LoveAll.png)

## Running instructions
Install the dependencies and start the server.

```sh
$ cd client
$ npm install
$ npm start
```
Runs the app in the development mode.<br>
Open [http://localhost:3000](http://localhost:3000) to view it in the browser. (uses proxy to connect to server running @ localhost:8070)

## TODO
* Parse result for GetScore and show is separately for each player instead of comma separated information
* Functionality to Add player via UI
* Prefer use Json to pass information from Server to UI vica versa
* Similarly, rely on ID instead of Names