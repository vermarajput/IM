# Tennis Score Orchestrator
Tennis Score Orchestrator is the solution to increment the score for two players and declare winner per set and for a match based on decision criteria
## Running instructions
Install the dependencies and start the server.

```sh
$ cd tennis
$ mvn clean install
## Run either of following commands to start application  
$ java -jar target/tennis-0.0.1-SNAPSHOT.jar
$ mvn spring-boot:run
```
Open [http://localhost:8070](http://localhost:8070) to view it in the browser.

### Screenshots
GetScore End point: ![](Get_GetScore.png)

## Swagger
Swagger live documentation can be accessed @ http://localhost:8070/swagger-ui.html
PointWonBy End point: ![](Post_PointsWonBy.png)

## TODO
* Functionality to Add players via separate end point
* Prefer use Json to pass information from Server to UI vica versa
* Similarly, rely on ID instead of Names
* Add Cucumber / Integration test cases