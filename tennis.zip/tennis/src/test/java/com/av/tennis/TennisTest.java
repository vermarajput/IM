package com.av.tennis;

import static java.lang.Math.max;
import static org.junit.Assert.*;

import java.util.Arrays;
import java.util.Collection;
import java.util.stream.IntStream;

import com.av.tennis.service.TennisGameServiceImpl;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameters;

@RunWith(Parameterized.class)
public class TennisTest {

    private int playerOneGameScore;
    private int playerTwoGameScore;
    private String expectedScore;

    public TennisTest(int playerOneGameScore, int playerTwoGameScore, String expectedScore) {
        this.playerOneGameScore = playerOneGameScore;
        this.playerTwoGameScore = playerTwoGameScore;
        this.expectedScore = expectedScore;
    }
    
    @Parameters
    public static Collection<Object[]> getAllScores() {
        return Arrays.asList(new Object[][] {
                { 0, 0,  "0 - 0, Love - All" },
                { 0, 3,  "0 - 0, Love - Forty" },
                { 0, 1,  "0 - 0, Love - Fifteen" },
                { 0, 2,  "0 - 0, Love - Thirty" },
                { 0, 4,  "0 - 1, Anu wins!" },
                { 1, 0,  "0 - 0, Fifteen - Love" },
                { 1, 1,  "0 - 0, Fifteen - All" },
                { 1, 2,  "0 - 0, Fifteen - Thirty" },
                { 1, 3,  "0 - 0, Fifteen - Forty" },
                { 1, 4,  "0 - 1, Anu wins!" },
                { 2, 0,  "0 - 0, Thirty - Love" },
                { 2, 1,  "0 - 0, Thirty - Fifteen" },
                { 2, 2,  "0 - 0, Thirty - All" },
                { 2, 3,  "0 - 0, Thirty - Forty" },
                { 2, 4,  "0 - 1, Anu wins!" },
                { 3, 0,  "0 - 0, Forty - Love" },
                { 3, 1,  "0 - 0, Forty - Fifteen" },
                { 3, 2,  "0 - 0, Forty - Thirty" },
                { 3, 3,  "0 - 0, Deuce" },
                { 3, 4,  "0 - 0, Advantage Anu" },
                { 4, 0,  "1 - 0, Aman wins!" },
                { 4, 1,  "1 - 0, Aman wins!" },
                { 4, 2,  "1 - 0, Aman wins!" },
                { 4, 3,  "0 - 0, Advantage Aman" },
                { 4, 4,  "0 - 0, Deuce" },
                { 4, 5,  "0 - 0, Advantage Anu" },
                { 5, 4,  "0 - 0, Advantage Aman" },
                { 4, 6,  "0 - 1, Anu wins!" },
                { 6, 4,  "1 - 0, Aman wins!" },
//                { 54, 0,  "Game Over: Aman won the Match. Resetting Scores." }
        });
    }

    @Test
    public void playGameAndCheckScore() {
        TennisGameServiceImpl game = new TennisGameServiceImpl();
        IntStream.range(0, max(this.playerOneGameScore, this.playerTwoGameScore)).forEachOrdered(i -> {
            if (i < this.playerOneGameScore)
                game.pointWonBy("Aman");
            if (i < this.playerTwoGameScore)
                game.pointWonBy("Anu");
        });
        assertEquals(this.expectedScore, game.getScore());
    }
}
