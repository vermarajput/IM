package com.av.tennis.model;

public class Player {

    private Integer gameScore;
    private Integer numberOfSetsWon;
    private String name;
    private String score;
    private Boolean matchWon = Boolean.FALSE;

    public Player(String name) {
        this.name = name;
        this.gameScore = 0;
        this.numberOfSetsWon = 0;
    }

    public Integer getGameScore() {
        return gameScore;
    }

    public void setGameScore(Integer gameScore) {
        this.gameScore = gameScore;
    }

    public Integer getNumberOfSetsWon() {
        return numberOfSetsWon;
    }

    public String getName() {
        return name;
    }

    public void setNumberOfSetsWon(Integer numberOfSetsWon) {
        this.numberOfSetsWon = numberOfSetsWon;
    }

    public String getScore() {
        return score;
    }

    public void setScore(String score) {
        this.score = score;
    }

    public Boolean getMatchWon() {
        return matchWon;
    }

    public void setMatchWon(Boolean matchWon) {
        this.matchWon = matchWon;
    }

    public void incrementScore() {
        this.gameScore++;
    }

    public void incrementSetsWon() {
        this.numberOfSetsWon++;
    }

     public void resetGameScore() {
            this.gameScore = 0 ;
     }

    public void resetSetScore() {
        this.numberOfSetsWon = 0;
    }
}
