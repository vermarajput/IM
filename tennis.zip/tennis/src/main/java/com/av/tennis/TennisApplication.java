package com.av.tennis;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TennisApplication {
    public static void main(String[] args) {
        SpringApplication.run(TennisApplication.class, args);
    }
}