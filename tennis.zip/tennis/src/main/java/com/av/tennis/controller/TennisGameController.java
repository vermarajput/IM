package com.av.tennis.controller;

import com.av.tennis.service.TennisGameService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

/**
 * @author Aman Verma created on 20 Sep 2019
 */
@RestController
@CrossOrigin
@RequestMapping("/api/v1")
@Api(value = "Tennis Score Management System")
public class TennisGameController {

    @Autowired
    private TennisGameService tennisGameService;

    @ApiOperation(value = "Add points for a player name passed.")
    @RequestMapping(value = "/pointsWonBy", method = RequestMethod.POST)
    public void pointsWonBy(@RequestParam String player) {
        tennisGameService.pointWonBy(player);
    }

    @ApiOperation(value = "Get score for both the players for latest game as well as all the sets played.")
    @RequestMapping(value = "/getScore", method = RequestMethod.GET)
    public String getScore() {
        return tennisGameService.getScore();
    }
}
