package com.av.tennis.model;

public enum Score{
    All,
    Love,
    Fifteen,
    Thirty,
    Fourty,
    Deuce,
    Advantage,
    Game
}