package com.av.tennis.service;

import com.av.tennis.model.Player;
import com.av.tennis.model.TennisGame;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import static java.lang.Math.abs;

/**
 *
 * // TODO:AV: Use Enum
 * // TODO:AV: Names hardcoded, should be captured via User Input.
 * // String Constants can be used with String.format
 *
 *
 * @author Aman Verma created on 20 Sep 2019
 */
@Service
public class TennisGameServiceImpl implements TennisGameService {
    private static final Logger log = LoggerFactory.getLogger(TennisGameServiceImpl.class);
    private static final String[] scores = new String[]{"Love", "Fifteen", "Thirty", "Forty"};
    private static final String AMAN = "Aman";
    private static final String ANU = "Anu";

    private final TennisGame tennisGame;

    public TennisGameServiceImpl() {
        this.tennisGame = new TennisGame(new Player(AMAN), new Player(ANU));
    }

    @Override
    public void pointWonBy(String playerName) {
        if (playerName.equals(AMAN)) {
            this.tennisGame.getPlayerOne().incrementScore();
        } else {
            this.tennisGame.getPlayerTwo().incrementScore();
        }
        updatedGameState();
    }

    @Override
    public String getScore() {
        if (this.tennisGame.getPlayerOne().getMatchWon()) {
            this.tennisGame.resetAll();
            return "Game Over: " + this.tennisGame.getPlayerOne().getName() + " won the Match. Resetting Scores.";
        }
        if (this.tennisGame.getPlayerTwo().getMatchWon()) {
            this.tennisGame.resetAll();
            return "Game Over: " + this.tennisGame.getPlayerTwo().getName() + " won the Match. Resetting Scores.";
        }
        return getSetsWon() +  ", " + this.tennisGame.getScore();
    }

    private String getSetsWon() {
        return this.tennisGame.getPlayerOne().getNumberOfSetsWon() + " - " + this.tennisGame.getPlayerTwo().getNumberOfSetsWon();
    }

    private void updatedGameState() {
        Integer playerOneGameScore = this.tennisGame.getPlayerOne().getGameScore();
        Integer playerTwoGameScore = this.tennisGame.getPlayerTwo().getGameScore();
        String playerOneName = this.tennisGame.getPlayerOne().getName();
        String playerTwoName = this.tennisGame.getPlayerTwo().getName();

        //Deuce
        if ( (playerOneGameScore == 3 || playerOneGameScore == 4) && playerOneGameScore == playerTwoGameScore) {
            log.debug(playerOneName + " : " + playerOneGameScore + " : " + playerTwoName + " : " + playerTwoGameScore  + " : " + " Deuce!");
            this.tennisGame.getPlayerOne().setGameScore(3);
            this.tennisGame.getPlayerTwo().setGameScore(3);
            this.tennisGame.setScore("Deuce");
        }
        //Game Score
        else if (playerOneGameScore < 4 && playerTwoGameScore < 4) {
            String tennisEqScoreP1 = scores[playerOneGameScore];
            String tennisEqScoreP2 = scores[playerTwoGameScore];
            String gameScore = (playerOneGameScore == playerTwoGameScore) ? tennisEqScoreP1 + " - All" : tennisEqScoreP1 + " - " + tennisEqScoreP2;
            this.tennisGame.setScore(gameScore);
            log.debug(playerOneName + ":"+ playerOneGameScore +"-"+  playerTwoName +":"+ playerTwoGameScore +" "+ gameScore);
        }
         else {
            //Advantage or Win
            String playerWithHigherScore = playerOneGameScore > playerTwoGameScore ? playerOneName : playerTwoName;
            if (abs(playerOneGameScore - playerTwoGameScore) == 1) {
                log.debug(playerOneName + ":"+ playerOneGameScore +"-"+  playerTwoName +":"+ playerTwoGameScore + " Advantage " + playerWithHigherScore);
                this.tennisGame.setScore("Advantage " + playerWithHigherScore);
            } else {
                setWinnerInfo(playerWithHigherScore);
                log.debug(playerOneName + ":"+ playerOneGameScore +"-"+  playerTwoName +":"+ playerTwoGameScore + " " + playerWithHigherScore + " wins! : " +
                        getSetsWon());
            }
        }
    }

    private void setWinnerInfo(String playerWithHigherScore) {
        String gameScore = playerWithHigherScore + " wins!";
        if (playerWithHigherScore.equals(this.tennisGame.getPlayerOne().getName())) {
            this.tennisGame.getPlayerOne().incrementSetsWon();
        } else {
            this.tennisGame.getPlayerTwo().incrementSetsWon();
        }

        if (this.tennisGame.getPlayerOne().getNumberOfSetsWon() >= 6){
            this.tennisGame.getPlayerOne().setMatchWon(true);
            this.tennisGame.resetPlayerLevelSetScore();
        } else if (this.tennisGame.getPlayerTwo().getNumberOfSetsWon() >= 6){
            this.tennisGame.getPlayerTwo().setMatchWon(true);
            this.tennisGame.resetPlayerLevelSetScore();
        }
        this.tennisGame.setScore(gameScore);
        this.tennisGame.resetPlayerLevelGameScore();

    }
}
