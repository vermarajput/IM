package com.av.tennis.model;

import static java.lang.Boolean.FALSE;

public class TennisGame {

    private final Player playerOne;
    private final Player playerTwo;
    private String score;

    public TennisGame(Player playerOne, Player playerTwo) {
        this.playerOne = playerOne;
        this.playerTwo = playerTwo;
        this.score = "Love - All";
    }

    public Player getPlayerOne() {
        return playerOne;
    }

    public Player getPlayerTwo() {
        return playerTwo;
    }

    public String getScore() {
        return score;
    }

    public void setScore(String score) {
        this.score = score;
    }

    public void resetPlayerLevelGameScore(){
        this.playerOne.resetGameScore();
        this.playerTwo.resetGameScore();
    }

    public void resetPlayerLevelSetScore(){
        this.playerOne.resetSetScore();
        this.playerTwo.resetSetScore();
    }

    public void resetAll(){
        resetPlayerLevelGameScore();
        resetPlayerLevelSetScore();
        this.playerOne.setMatchWon(FALSE);
        this.playerTwo.setMatchWon(FALSE);
        this.score = "Love - All";
    }
}
