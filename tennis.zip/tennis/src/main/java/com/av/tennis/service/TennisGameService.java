package com.av.tennis.service;

public interface TennisGameService {
    void pointWonBy(String playerName);

    String getScore();
}